﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;


namespace WebServiceTest
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string Insert(string Fname, string Lname, string Email, string Mobile, string Country, string State, string Address)
        {
            string returntxt;
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            SqlConnection Conn = new SqlConnection(ConnStr);
            try
            {

                SqlCommand cmd = new SqlCommand("Insert Into Customer([FirstName] , [LastName] , [Email] , [MobileNo] , [Country] , [State] , [Address] ) " +
                    "Values (@Fname,@LName,@Email,@Phone,@Country,@State,@Address)", Conn);
                cmd.Parameters.AddWithValue("@Fname", Fname);
                cmd.Parameters.AddWithValue("@LName", Lname);
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@Phone", Mobile);
                cmd.Parameters.AddWithValue("@Country", Country);
                cmd.Parameters.AddWithValue("@State", State);
                cmd.Parameters.AddWithValue("@Address", Address);

                Conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                {
                    returntxt = "success";

                }
                else
                {
                    returntxt = "failed";
                }
                return returntxt;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                Conn.Close();

            }

        }
        [WebMethod]
        public string Update(string Fname, string Lname, string Email, string Mobile, string Country, string State, string Address, int CustomerId)
        {
            string returntxt;
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            SqlConnection Conn = new SqlConnection(ConnStr);
            try
            {

                SqlCommand cmd = new SqlCommand(" Update Customer Set [FirstName]=@Fname , [LastName]=@LName , [Email]=@Email , [MobileNo]=@Phone , [Country]=@Country , [State]=@State , [Address] =@Address Where CustomerId=@CustomerId", Conn);
                cmd.Parameters.AddWithValue("@Fname", Fname);
                cmd.Parameters.AddWithValue("@LName", Lname);
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@Phone", Mobile);
                cmd.Parameters.AddWithValue("@Country", Country);
                cmd.Parameters.AddWithValue("@State", State);
                cmd.Parameters.AddWithValue("@Address", Address);
                cmd.Parameters.AddWithValue("@CustomerId", Convert.ToInt32(CustomerId));

                Conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                {
                    returntxt = "success";

                }
                else
                {
                    returntxt = "failed";
                }
                return returntxt;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                Conn.Close();

            }

        }

        [WebMethod]
        public List<Customer> GetCustomer(int CustomerId)
        {
            string SqlText = "Select * from Customer ";
            Customer cs = new Customer();
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            SqlConnection Conn = new SqlConnection(ConnStr);
            if (CustomerId > 0)
            {
                SqlText = SqlText + " Where CustomerId=" + CustomerId;
            }

            try
            {
               
                SqlCommand cmd = new SqlCommand(SqlText, Conn);
                Conn.Open();
                List<Customer> csl = new List<Customer>();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    cs.Id = Convert.ToInt32(rdr["CustomerId"]);
                    cs.Fname = rdr["FirstName"].ToString();
                    cs.Lname = rdr["LastName"].ToString();
                    cs.Email = rdr["Email"].ToString();
                    cs.Mobile = rdr["MobileNo"].ToString();
                    cs.Country = rdr["Country"].ToString();
                    cs.State = rdr["State"].ToString();
                    cs.Address = rdr["Address"].ToString();
                    csl.Add(cs);
                }

                return csl;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                Conn.Close();
            }
        }


        [WebMethod]
        public string DeleteCustomer(int CustomerId)
        {
            string returntxt;
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            SqlConnection Conn = new SqlConnection(ConnStr);
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Customer where CustomerId=@CustomerId",Conn);
                cmd.Parameters.AddWithValue("@CustomerId", CustomerId);
                Conn.Open();
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    returntxt = "Success";
                }
                else
                {
                    returntxt = "Failed";
                }
                return returntxt;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                Conn.Close();
            }
        }

        [WebMethod]
        public List<Customer> SearchCustomer(string SearchText)
        {
            string SqlText = "Select * from Customer  where	 [FirstName] like '%"+SearchText+ "%' OR [LastName]  like '%" + SearchText + "%' OR [Email]  like '%" + SearchText + "%' OR [MobileNo]  like '%" + SearchText + "%' OR [Country]  like '%" + SearchText + "%' OR [State] like '%" + SearchText + "%' OR [Address] like '%" + SearchText + "%' ";
            Customer cs = new Customer();
            string ConnStr = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            SqlConnection Conn = new SqlConnection(ConnStr);
            

            try
            {

                SqlCommand cmd = new SqlCommand(SqlText, Conn);
                Conn.Open();
                List<Customer> csl = new List<Customer>();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    cs.Id = Convert.ToInt32(rdr["CustomerId"]);
                    cs.Fname = rdr["FirstName"].ToString();
                    cs.Lname = rdr["LastName"].ToString();
                    cs.Email = rdr["Email"].ToString();
                    cs.Mobile = rdr["MobileNo"].ToString();
                    cs.Country = rdr["Country"].ToString();
                    cs.State = rdr["State"].ToString();
                    cs.Address = rdr["Address"].ToString();
                    csl.Add(cs);
                }

                return csl;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                Conn.Close();
            }
        }
    }
}
